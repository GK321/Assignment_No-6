Indian_state_Capital=[
    {
        "state": "Maharashtra",
        "capital": "Mumbai "
    },
    {
        "state": "Gujrat",
        "capital": "Gandhinagar" 
    },
    {
        "state": "Goa",
        "capital": "Punaji"
    },
    {
        "state": "Himachal Pradesh",
        "capital": "Shimla"
    },
    {
        "state": "Karnataka",
        "capital": "Bangaluru"
    }
]    
import json
json_string = json.dumps(Indian_state_Capital)  
print(json_string)


