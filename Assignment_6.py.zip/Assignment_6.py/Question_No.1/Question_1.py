Employe=[
   {
    "Employe_No" : 1,
    "Name":"Gajanan Kabure",
    "DOB":"03/09/1998",
    "Height":"5.10",
    "City":"Mumbai",
    "State":"Maharashtra"
    },
    {
    "Employe_No" : 2,
    "Name": "Rishita Gupta",
    "DOB": "03/03/2000",
    "Height": "5.01",
    "City": "Himachal",
    "State": "Himachal Pradesh"
    },
    {
    "Employe_No" : 3,
    "Name": "Atul Gupta",
    "DOB": "12/05/2001",
    "Height": "5.6",
    "City": "Vasai",
    "State": "Maharashtra"
    },   
    {
    "Employe_No" : 4,
    "Name": "Spoorti Jadhav",
    "DOB": "21/10/1997",
    "Height": "4.09",
    "City": "Hubali",
    "State": "Karnataka"
    },
    {
    "Employe_No" : 5,
    "Name": "Jayesh Chaudhari",
    "DOB": "17/01/2001",
    "Height": "6.01",
    "City": "Vashi",
    "State": "Maharashtra"
    }  
]
import json
json_string = json.dumps(Employe)
print(json_string)

for i in json_string:json.dumps('Employe')
print(i)
