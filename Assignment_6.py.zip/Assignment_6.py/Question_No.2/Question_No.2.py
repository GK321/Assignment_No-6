class Dog:
    def __init__(self, name, age, coat_color):
        self.name = name
        self.age = age
        self.coat_color = coat_color

    def description(self):
        print(f"The name of the dog is {self.name}")
        print(f"The dog's age is {self.age}")

    def get_info(self):
        print(f"The coat color of {self.name} is {self.coat_color}")
class JackRussellTerrier(Dog):

    def __init__(self, name, age, coat_color):
        super().__init__(name, age, coat_color)

    def weight(self, weight=31):
        self.weight = weight
        print(f"The weight of {self.name} is {self.weight} Kilogram")

    def life_span(self, lifespan = 15):
        self.lifespan = lifespan
        print(f"The lifespan of {self.name} is {self.lifespan} years")

class Bulldog(Dog):

    def __init__(self, name, age, coat_color="White",gender="Female"):
        super().__init__(name, age, coat_color)
        self.gender = gender

    def height(self, height=16):
        self.height = height
        print(f"The height of {self.name} is {self.height} inches")

    def bark(self, bark):
        self.bark = bark
        print(f"{self.name} is a {self.gender} and says {self.bark}")
tom = JackRussellTerrier("Jonny", 9, "Brown")
tom.description()
tom.get_info()
tom.weight()
tom.life_span(18)

rocky = Bulldog("Rocky", 7, "Red", "Male")
rocky.description()
rocky.get_info()
rocky.height(17)
rocky.bark("Woooofffyyyywooffywooo!")